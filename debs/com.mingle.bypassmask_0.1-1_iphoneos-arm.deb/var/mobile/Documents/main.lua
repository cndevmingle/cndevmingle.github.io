 local varFiles={
    "backups",
    "buddy",
    ["cache"]={"findutils"},
    "containers",
    "db",
    "empty",
    "folders",
    "hardware",
    "installd",
    "iomfb_bics_daemon",
    "keybags",
    "Keychains",
    "local",
    "lock",
    "MobileSoftwareUpdate",
    log={
        "asl",
        "com.apple.xpc.launchd",
        "ppp"
    },
    "logs",
    "Managed Preferences",
    "MobileAsset",
    "MobileDevice",
    "msgs",
    "networkd",
    "preferences",
    "root",
    "run",
    "spool",
    "staged_system_apps",
    "vm",
    "wireless",
    ["tmp"]={
        "com.apple.DragUI.druid",
        "com.apple.mobileassetd",
        "com.apple.MobileAccessoryUpdater",
        "com.apple.transparencyd",
        "com.apple.trustd",
        "com.apple.healthappd",
        "com.apple.revisiond",
        "com.apple.CallKit.CallDirectory",
        "com.apple.appstored",
        "com.apple.locationd",
        "com.apple.proactiveeventtrackerd",
        "com.apple.fitcored",
        "com.apple.ClipServices.clipserviced",
        "com.apple.businesschatd",
        "com.apple.icloud.searchpartyd",
        "com.apple.useractivityd",
        "com.apple.dmd",
        "com.apple.swcd",
        "com.apple.passd",
        "com.apple.remindd",
        "com.apple.voicememod",
        "com.apple.cloudd",
        "com.apple.pasteboard.pasted",
        "com.apple.siri-distributed-evaluation",
        "com.apple.announced",
        "com.apple.ptpd",
        "com.apple.wifianalyticsd",
        "com.apple.UsageTrackingAgent"
    },
    mobile={
        "Applications",
        "Containers",
        Documents={
            "com.apple.springboard.appLibrary"
        },
        "Downloads",
        Media={
            "Airlock",
            "AirFair",
            "Downloads",
            "Books",
            "Photos",
            "Recordings",
            "DCIM",
            "iTunes_Control",
            "PhotoData",
            "PublicStaging",
        },
        "MobileSoftwareUpdate",
        Library={
            "Accessibility",
            "Accounts",
            "AddressBook",
            "AggregateDictionary",
            "AirPlayRoutePrediction",
            "ApplePushService",
            "Application Support",
            "Assistant",
            "Avatar",
            "BulletinBoard",
            "Calendar",
            "CallDirectory",
            "CallHistoryDB",
            "CallHistoryTransactions",
            "CallServices",
            "Carrier Bundle.bundle",
            "Carrier Bundles",
            "Carrier1Bundle.bundle",
            "CarrierDefault.bundle",
            "ClassKit",
            "com.apple.icloud.searchpartyd",
            "com.apple.internal.ck",
            "com.apple.iTunesCloud",
            "com.apple.itunesstored",
            "com.apple.nsurlsessiond",
            "com.apple.nsurlsessiond-launchd",
            "com.apple.WatchListKit",
            "Contacts",
            "ControlCenter",
            "CoreAccessories",
            "CoreAS",
            "CoreBehavior",
            "CoreDuet",
            "CoreFollowUp",
            "coreidvd",
            "DeviceRegistry.dontBackUp",
            "DeviceRegistry.state",
            "DifferentialPrivacy",
            "dmd",
            "DoNotDisturb",
            "DuetActivityScheduler",
            "DuetExpertCenter",
            "ExposureNotification",
            "FairPlay",
            "FrontBoard",
            "Health",
            "homed",
            "IdentityServices",
            "Intents",
            "Keyboard",
            "KeyboardServices",
            "LASD",
            "locationd",
            "mad",
            "Mail",
            "MediaRemote",
            "MediaStream",
            "MessagesMetaData",
            "MobileContainerManager",
            "NanoMusicSync",
            "NFStorage",
            "Notes",
            "OnDemandResources",
            "Operator Bundle.bundle",
            "Operator1Bundle.bundle",
            "OSAnalytics",
            "OTALogging",
            "Passes",
            "PersonalizationPortrait",
            "PowerUI",
            "Reminders",
            "Safari",
            "SecureElementService",
            "Sharing",
            "SMS",
            "SoftwareUpdate",
            --"SplashBoard",
            "Spotlight",
            "SpringBoard",
            "Suggestions",
            "SyncedPreferences",
            "TCC",
            "Trial",
            "UserConfigurationProfiles",
            "UserFonts",
            "UserNotifications",
            "UserNotificationsServer",
            "Voicemail",
            "WelcomeMat",
            "Preferences",
            Logs={
                "AppleSupport",
                "ExposureNotification",
                "SMSMigrator",
                "Bluetooth",
                "mobileactivationd",
                "NotificationProxy",
                "com.apple.ioam",
                "com.apple.itunesstored",
                "CoreDuet",
                "DiagnosticPipeline",
            },
            ['Saved Application State']={
                "com.apple.purplebuddy.savedState",
                "com.apple.camera.savedState",
                "com.apple.Preferences.savedState",
            },
            Caches={
                "CloudKit",
                "com.apple.mediaserverd",
                "com.apple.keyboards",
                "com.apple.kbd",
                "com.apple.akd",
                "MappedImageCache",
                "sharedCaches",
                "com.apple.Search.framework",
                "com.apple.appstored",
                "com.apple.backboardd",
                "VoiceServices",
                "com.apple.Safari.SafeBrowsing",
                "com.apple.atc",
                "com.apple.accountsd",
                "com.apple.tipsd",
                "com.apple.itunescloudd",
                "com.apple.Pasteboard",
                "com.apple.nsurlsessiond",
                "PassKit",
                "com.apple.AppleMediaServices",
                "com.apple.Preferences",
                "com.apple.passd",
                "com.apple.remindd",
                "com.apple.itunesstored",
                "com.apple.mobileactivationd",
                "com.apple.parsecd",
                "com.apple.geod",
                "GeoServices",
                "com.apple.iTunesStore",
                "com.apple.routined",
                "com.apple.Maps.Suggestions",
                "com.apple.storeservices",
                "com.apple.springboard",
                "com.apple.purplebuddy",
                "com.apple.watchlistd",
                "com.apple.navd",
                "rtcreportingd",
                "com.apple.cache_delete",
                "com.apple.iTunesCloud",
                "com.apple.AppleAccount",
                "com.apple.ap.adprivacyd",
                "com.apple.coreidv.coreidvd",
            }
        }
    }
}

local config={
    root = '/private/var/Mask',
    mnt = '/private/var/Mask/mnt1',
    dev = '/private/var/Mask/mnt1/dev',
    var = '/private/var/Mask/mnt1/private/var',
    containers = '/private/var/Mask/mnt1/private/var/containers',
    varVolume = 'mask-var',
    rootVolume = 'mask-root'
}

local ffi=require 'ffi'
local lfs=require 'lfs'
local snapfs=require 'snapfs'
local plist = require 'plist'

ffi.cdef[[
    typedef int uid_t;
    typedef int gid_t;
    typedef uint16_t mode_t;
    struct timezone {
        int tz_minuteswest;
        int tz_dsttime;
    };
    struct hfs_mount_args {
        const char *fspec;
        uid_t hfs_uid;
        gid_t hfs_gid;
        mode_t hfs_mask;
        uint32_t hfs_encoding;
        struct timezone hfs_timezone;
        int     flags;
        int journal_tbuffer_size;
        int     journal_flags;
        int     journal_disable;
    };
    int mount(const char *fstype, const char *path, int flags, void *arg);
    int unmount(const char *path,int flags);
    int gettimeofday(void *tv,void *tz);
    int mkdir(const char *path, mode_t mode);
    int chmod(const char *path, mode_t pmode);
    int chown(const char *path, uint16_t uid, uint16_t gid);
    int access(const char *path, int mode);
    unsigned int sleep (unsigned int seconds);
    int  APFSVolumeDelete ( const  char *path);

    bool copy_file_in_memory(const char *destPath, const char *srcPath, bool flag);

    int CFUserNotificationDisplayAlert(double timeout, unsigned long flags, void *iconURL, void *soundURL, void *localizationURL, void *alertHeader,void *alertMessage, void *defaultButtonTitle,void *alternateButtonTitle, void *otherButtonTitle, unsigned long *responseFlags);
    void* CFStringCreateWithCString(void *alloc,const char *str,int encoding);
    void CFRelease(void *cf);
]]

local gettimeofday = ffi.C.gettimeofday
local mount = ffi.C.mount
local unmount = ffi.C.unmount
local mkdir=ffi.C.mkdir
local chmod=ffi.C.chmod
local chown=ffi.C.chown
local access=ffi.C.access
local APFSVolumeDelete = ffi.C.APFSVolumeDelete
local kernelHardLink = ffi.C.copy_file_in_memory
local sleep = ffi.C.sleep
local CFUserNotificationDisplayAlert = ffi.C.CFUserNotificationDisplayAlert
local CFStringCreateWithCString = ffi.C.CFStringCreateWithCString
local CFRelease = ffi.C.CFRelease

local function fileExists(path)
    return access(tostring(path),0)==0
end

local function isemptyDir(path)
    local count=0
    for file in lfs.dir(tostring(path)) do
        count=count+1
    end
    return count==2
end

local function makeDir(path,mode,uid,gid)
    local filePath=tostring(path)
    if mkdir(filePath,493) ~= 0 then return false end
    if type(mode)=="number" then
        chmod(filePath,mode)
    end
    if type(uid)=="number" and type(gid)=="number" then
        chown(filePath,uid,gid)
    end
    return true
end

local function makeFile(path,mode,uid,gid)
    local filePath=tostring(path)
    local file=io.open(filePath,"w")
    if not file then return false end
    file:close()
    if type(mode)=="number" then
        chmod(filePath,mode)
    end
    if type(uid)=="number" and type(gid)=="number" then
        chown(filePath,uid,gid)
    end
    return true
end

local function popen(cmd)
    local pipe = io.popen(cmd,'r');
    if not pipe then return end
    local str=pipe:read('*all')
    local flag,state,code = pipe:close()
    --if not flag then return nil,code,str  end
    --return str,code
    return str,flag,code
end

local volume={}
function volume.list()
    local volumes={}
    for file in lfs.dir('/dev') do
        if string.match(file,'disk0s1s%d+') then
            local path = '/dev/'..file
            local name = popen('/System/Library/Filesystems/apfs.fs/apfs.util -p '..path) or ''
            volumes[#volumes+1] = {
                path=path,
                name=name
            }
        end
    end
    return volumes
end

function volume.exists(name)
    local list = volume.list()
    for _,value in pairs(list) do
        if value.name == name then
            return value.path
        end
    end
end

function volume.new(name)
    local path = volume.exists(name)
    if not path then
        os.execute(string.format([[newfs_apfs -v "%s" -A /dev/disk0s1]],tostring(name)))
    end
    return volume.exists(name)
end

function volume.delete(name)
    local path = volume.exists(name)
    if not path then return true end
    local ret = APFSVolumeDelete(path)
    return ret == 0
end

function volume.mount(name,path)
    local dev = volume.exists(name)
    if not dev then return false end
    --return os.execute(string.format('mount_apfs %s %s',dev,path))

    local mountarg = ffi.new("struct hfs_mount_args",{dev,0,0,1,0,{0,0},0,0,0,0})
    local mountarg_p = ffi.cast('void *',mountarg)
    --gettimeofday(ffi.NULL,mountarg_p)

    local flag = mount("apfs",path,0,mountarg_p)

    return (flag == 0)
end

local function mountlist()
    local str = popen('df -h') or ' \n'
    local mounts={}
    local keys={'filesystem','size','used','avail','capacity','iused','ifree','%iused','mounted'}
    local iter = str:gmatch('([^\n]+)')
    iter()
    for line in iter do
        local count=1
        local info={}
        for value in line:gmatch('[^ ]+') do
            info[keys[count]] = value
            count = count+1
        end
        mounts[#mounts+1] = info
    end
    return mounts
end

local function getMountInfoFromPath(path)
    local list = mountlist()
    for _,value in ipairs(list) do
        if value.mounted == path then
            return value
        end
    end
end

local function launchctlList()
    local str = popen("launchctl list") or '\n'
    local iter = str:gmatch('([^\n]+)')
    iter()
    local list={}
    local keys = {'pid','status','label'}
    for line in iter do
        local server={}
        local count = 1
        for info in line:gmatch('([^%s^ ]+)') do
            server[keys[count] or ''] = info
            count = count + 1
        end
        list[#list+1] = server
    end
    return list
end

local ssh={}
function ssh.isRunning()
    local list = launchctlList()
    for _,value in pairs(list) do
        if string.match(value.label, "dropbear%..+") then
            return true
        end
        if string.match(value.label, "openssh") then
            return true
        end
    end
end

function ssh.dis()
    os.execute("launchctl stop dropbear")
    os.execute("launchctl stop com.openssh.sshd")
    os.execute("launchctl unload /binpack/Library/LaunchDaemons/dropbear.plist")
    os.execute("launchctl unload /Library/LaunchDaemons/com.openssh.sshd.plist")
    local list = launchctlList()
    for _,value in pairs(list) do
        if string.match(value.label or '', "dropbear%..+") then
            os.execute("launchctl stop "..value.label)
        end
    end
end

function ssh.enable()
    os.execute("launchctl load /binpack/Library/LaunchDaemons/dropbear.plist")
    os.execute("launchctl load /Library/LaunchDaemons/com.openssh.sshd.plist")
end

local function copySysFilesStructFromTable(sysPath,destPath,files)
    for key,value in pairs(files) do
        if type(value) == 'string' then
            local sysFile=sysPath..'/'..value
            local destFile=destPath..'/'..value
            local attr=lfs.attributes(sysFile)
            if attr and not fileExists(destFile) then
                if attr.mode == 'directory' then
                    local flag = makeDir(destFile,attr.mode_t,attr.uid,attr.gid)
                    print(string.format("%s:创建目录 '%s'",flag and '✅' or '❌',destFile))
                elseif attr.mode == 'file' then
                    local flag = makeFile(destFile,attr.mode_t,attr.uid,attr.gid)
                    print(string.format("%s:创建文件 '%s'",flag and '✅' or '❌',destFile))
                end
            end
        elseif type(value) == 'table' then
            local sysFile=sysPath..'/'..key
            local destFile=destPath..'/'..key
            local attr=lfs.attributes(sysFile)
            if attr then
                if attr.mode == 'directory' then
                    if makeDir(destFile,attr.mode_t,attr.uid,attr.gid) then
                        copySysFilesStructFromTable(sysFile,destFile,value)
                    end
                end
            end
        end
    end
end

local function hardlinkFilesWithTable(sysPath,destPath,fileList)
    for key,value in pairs(fileList) do
        if type(value) == 'string' then
            local sysFile=sysPath..'/'..value
            local destFile=destPath..'/'..value
            if fileExists(sysFile) and fileExists(destFile) then
                local flag=kernelHardLink(destFile,sysFile,true)
                print(string.format("%s:硬链接(%s --> %s)",flag and '✅' or '❌',sysFile,destFile))
            end
        elseif type(value) == 'table' then
            local sysFile=sysPath..'/'..key
            local destFile=destPath..'/'..key
            if fileExists(sysFile) and fileExists(destFile) then
                hardlinkFilesWithTable(sysFile,destFile,value)
            end
        end
    end
end

--[[
local function randomBootHash()
    local ascii = {{0x41,0x5A},{0x30,0x39}}
    local hash={}
        math.randomseed(os.time())
    for i=1,96 do
        local range = ascii[math.random(1,#ascii)]
        hash[i]=math.random(math.min(table.unpack(range)),math.max(table.unpack(range)))
    end
    local hashstr = string.char(table.unpack(hash))
    return "com.apple.os.update-"..hashstr
end
--]]

local function main()

    if not fileExists(config.root) then
        if not os.execute(string.format([[mkdir -p "%s"]],config.root)) then
            return print("❌:创建挂载点失败!")
        end
    end

    if not getMountInfoFromPath(config.root) then
        if not volume.exists(config.rootVolume) then
            volume.new(config.rootVolume)
        end
        if not volume.mount(config.rootVolume,config.root) then
            return print("❌:挂载分区失败!")
        end
    end
    print("✅:挂载分区完成")

    if not fileExists(config.mnt) then
        if not os.execute(string.format([[mkdir -p "%s"]],config.mnt)) then
            return print("❌:创建挂载点失败!")
        end
    end
    print("✅:创建挂载点完成")

    if not getMountInfoFromPath(config.mnt) then
        local flag,code,err=snapfs.mount('/',config.mnt,'orig-fs')
        if not flag then
            return print(string.format("❌:挂载rootfs失败(%d):%s",code,tostring(err)))
        end
    end
    print("✅:挂载rootfs完成")

    if not getMountInfoFromPath(config.dev) then
        if mount('devfs',config.dev,0,ffi.NULL) ~= 0 then
            return print("❌:挂载devfs失败")
        end
    end
    print("✅:挂载devfs完成")

    if not getMountInfoFromPath(config.var) then
        if not volume.exists(config.varVolume) then
            volume.new(config.varVolume)
        end
        if not volume.mount(config.varVolume, config.var) then
            return print("❌:挂载var失败!")
        end
    end
    print("✅:挂载var完成")

    --if not fileExists(config.containers) then
    copySysFilesStructFromTable('/private/var',config.var,varFiles)
    --end
    if not fileExists(config.containers) then
        return print("❌:构建var目录错误!");
    end
    print("✅:var目录构建完成")

    if not fileExists(config.containers) or isemptyDir(config.containers) then
        hardlinkFilesWithTable('/private/var',config.var,varFiles)
        kernelHardLink(config.mnt..'/usr/lib/swift','/usr/lib/swift',true)
    end
    if not fileExists(config.containers) or isemptyDir(config.containers) then
        return print("❌:rootfs构建失败!")
    end
    print("✅:rootfs构建完成!")

    local daemonPlist = {
        ['Program']='/usr/bin/jailbreakMaskd',
        ['ProgramArguments']={
            [1]=config.mnt
        },
        ['KeepAlive'] = true,
        ['Label'] = 'com.jailbreak.maskd',
        ['RunAtLoad'] = true,
        ["StandardErrorPath"]="/dev/null"
    }
    plist.write('/Library/LaunchDaemons/com.jailbreak.maskd.plist',daemonPlist)
    os.execute('launchctl unload /Library/LaunchDaemons/com.jailbreak.maskd.plist')
    sleep(1)
    if not os.execute('launchctl load /Library/LaunchDaemons/com.jailbreak.maskd.plist') then
        return print("❌:启用守护进程失败!")
    end
    print("✅:启用守护进程完成")

    if ssh.isRunning then
        local alertHeader = CFStringCreateWithCString(ffi.NULL,"将要禁用SSH",0x08000100)
        local alertMessage = CFStringCreateWithCString(ffi.NULL,"某些应用可能通过扫描SSH端口检测越狱。禁用后你可以通过停止mask重新启用SSH",0x08000100)
        local defaultButtonTitle = CFStringCreateWithCString(ffi.NULL,"确定",0x08000100)

        CFUserNotificationDisplayAlert(5, 3, ffi.NULL, ffi.NULL, ffi.NULL,
            alertHeader,alertMessage,defaultButtonTitle,
            ffi.NULL,ffi.NULL,ffi.NULL
        )

        CFRelease(alertHeader)
        CFRelease(alertMessage)
        CFRelease(defaultButtonTitle)

        ssh.dis()
        print("✅:禁用ssh完成!")
    end
end
main()
